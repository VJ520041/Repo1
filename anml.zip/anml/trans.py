def run_lstm_forecast(file_path, district, mrp, target_month):
    import pandas as pd
    import numpy as np
    import torch
    import torch.nn as nn
    import matplotlib.pyplot as plt
    from sklearn.preprocessing import MinMaxScaler
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    seq_len, hidden_size, num_layers, num_epochs, lr, batch_size = 12, 64, 2, 500, 0.01, 16

    df = pd.read_excel(file_path, sheet_name='Sheet3')
    df['Billing Date'] = pd.to_datetime(df['Billing Date'])
    df = df[(df['District'] == district) & (df['MRP'] == mrp)]
    df = df[['Billing Date', 'Billed Quantity']]

    all_dates = pd.date_range(start='2017-04-01', end='2024-12-31', freq='D')
    df = df.groupby('Billing Date').sum().reindex(all_dates, fill_value=0)
    df.index.name = 'Date'
    df.reset_index(inplace=True)

    df['YearMonth'] = df['Date'].dt.to_period('M')
    monthly_sales = df.groupby('YearMonth')['Billed Quantity'].sum().reset_index()
    monthly_sales['YearMonth'] = monthly_sales['YearMonth'].dt.to_timestamp()

    scaler = MinMaxScaler()
    scaled_data = scaler.fit_transform(monthly_sales[['Billed Quantity']])
    series = torch.FloatTensor(scaled_data).view(-1)

    def create_sequences(series, seq_len):
        xs, ys = [], []
        for i in range(len(series) - seq_len):
            x = series[i:i+seq_len]
            y = series[i+seq_len]
            xs.append(x)
            ys.append(y)
        return torch.stack(xs), torch.stack(ys)

    X, y = create_sequences(series, seq_len)

    target_timestamp = pd.to_datetime(f"{target_month}-01")
    target_index = monthly_sales[monthly_sales['YearMonth'] == target_timestamp].index[0]
    if target_index < seq_len:
        raise ValueError("Not enough data before the selected target month.")

    X_input = series[target_index - seq_len:target_index].unsqueeze(0).to(device)
    y_actual = monthly_sales.loc[target_index, 'Billed Quantity']

    X_train, y_train = X[:target_index - seq_len], y[:target_index - seq_len]
    train_dataset = torch.utils.data.TensorDataset(X_train, y_train)
    train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=batch_size, shuffle=True)

    class LSTMModel(nn.Module):
        def __init__(self, input_size=1, hidden_size=64, num_layers=2):
            super().__init__()
            self.lstm = nn.LSTM(input_size, hidden_size, num_layers, batch_first=True)
            self.fc = nn.Linear(hidden_size, 1)

        def forward(self, x):
            x = x.unsqueeze(-1)
            out, _ = self.lstm(x)
            out = self.fc(out[:, -1, :])
            return out.squeeze()


    model = LSTMModel(hidden_size=hidden_size, num_layers=num_layers).to(device)

    criterion = nn.MSELoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)

    for epoch in range(num_epochs):
        model.train()
        for batch_x, batch_y in train_loader:
            batch_x, batch_y = batch_x.to(device), batch_y.to(device)
            output = model(batch_x)
            loss = criterion(output, batch_y)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

    model.eval()
    with torch.no_grad():
        y_pred = model(X_input).cpu().item()

    y_pred_inv = scaler.inverse_transform([[y_pred]])[0][0]

    # Plot
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.bar(['Actual', 'Predicted'], [y_actual, y_pred_inv], color=['blue', 'orange'])
    ax.set_title(f"Sales Prediction - {target_month} ({district}, MRP {mrp})")
    ax.set_ylabel("Billed Quantity")
    ax.grid(True, axis='y')
    plt.tight_layout()

    return y_actual, y_pred_inv, fig
