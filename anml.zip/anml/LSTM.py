import pandas as pd
import numpy as np
import torch
import torch.nn as nn
from sklearn.preprocessing import MinMaxScaler
from torch.utils.data import Dataset, DataLoader

# Simple LSTM model
class SalesLSTM(nn.Module):
    def __init__(self, input_size=1, hidden_size=32, num_layers=1, output_size=1):
        super(SalesLSTM, self).__init__()
        self.lstm = nn.LSTM(input_size, hidden_size, num_layers, batch_first=True)
        self.linear = nn.Linear(hidden_size, output_size)

    def forward(self, x):
        lstm_out, _ = self.lstm(x)
        return self.linear(lstm_out[:, -1, :])

# Dataset wrapper
class SalesDataset(Dataset):
    def __init__(self, series, window_size):
        self.x = []
        self.y = []
        for i in range(len(series) - window_size):
            self.x.append(series[i:i+window_size])
            self.y.append(series[i+window_size])
        self.x = torch.tensor(self.x, dtype=torch.float32)
        self.y = torch.tensor(self.y, dtype=torch.float32)

    def __len__(self):
        return len(self.x)

    def __getitem__(self, idx):
        return self.x[idx], self.y[idx]

# Core function
def lstm(filtered_df, year, month, window_size=7):
    # Ensure Billing_Date is datetime
    filtered_df['Billing_Date'] = pd.to_datetime(filtered_df['Billing_Date'])
    # Group by date (in case of duplicates)
    ts = filtered_df.groupby('Billing_Date')['Sum_of_Billed_Quantity'].sum()
    ts = ts.asfreq('D').fillna(0)  # Ensure daily frequency
    
    # Scale the data
    scaler = MinMaxScaler()
    ts_scaled = scaler.fit_transform(ts.values.reshape(-1, 1)).flatten()

    # Prepare dataset
    dataset = SalesDataset(ts_scaled, window_size)
    dataloader = DataLoader(dataset, batch_size=4, shuffle=True)

    # Define model
    model = SalesLSTM()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = model.to(device)
    criterion = nn.MSELoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=0.01)

    # Train the model
    model.train()
    for epoch in range(100):
        for x_batch, y_batch in dataloader:
            x_batch = x_batch.unsqueeze(-1).to(device)
            y_batch = y_batch.to(device)
            output = model(x_batch).squeeze()
            loss = criterion(output, y_batch)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

    # Forecasting
    model.eval()
    preds = []
    input_seq = torch.tensor(ts_scaled[-window_size:], dtype=torch.float32).unsqueeze(0).unsqueeze(-1).to(device)

    # Predict number of days in selected month/year
    days_in_month = pd.date_range(f'{year}-{month:02d}-01', periods=31, freq='D')
    actual_days = [d for d in days_in_month if d.month == int(month)]

    for _ in range(len(actual_days)):
        with torch.no_grad():
            pred = model(input_seq)
            preds.append(pred.item())
            new_input = pred.unsqueeze(-1)  # shape (1, 1)
            input_seq = torch.cat([input_seq[:, 1:, :], new_input], dim=1)

    # Inverse transform predictions
    preds = np.array(preds).reshape(-1, 1)
    pred_rescaled = scaler.inverse_transform(preds).flatten()

    return pred_rescaled
