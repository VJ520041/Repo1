import pandas as pd
import numpy as np
import torch
import torch.nn as nn
from sklearn.preprocessing import MinMaxScaler
import matplotlib.pyplot as plt

def run_transformer_forecast(file_path, district_selected, mrp_selected):
    window_size = 30
    hidden_size = 64
    num_layers = 2
    nhead = 4
    batch_size = 64
    num_epochs = 100
    learning_rate = 0.001
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    df = pd.read_excel(file_path)
    df['Billing Date'] = pd.to_datetime(df['Billing Date'])
    df = df[(df['District'] == district_selected) & (df['MRP'] == mrp_selected)]

    full_range = pd.date_range(start='2017-04-01', end='2025-04-30', freq='D')
    df = df.groupby('Billing Date')['Billed Quantity'].sum().reindex(full_range, fill_value=0).reset_index()
    df.columns = ['Date', 'Quantity']
    df['Day'] = df['Date'].dt.day
    df['Month'] = df['Date'].dt.month
    df['Year'] = df['Date'].dt.year

    features = ['Day', 'Month', 'Year', 'Quantity']
    scaler = MinMaxScaler()
    scaled = scaler.fit_transform(df[features])
    target_col_idx = features.index('Quantity')

    split_date = pd.Timestamp('2024-01-01')
    train_idx = df['Date'] < split_date
    test_idx = (df['Date'] >= split_date) & (df['Date'] < pd.Timestamp('2025-01-01'))

    def create_sequences(data, window_size, target_col_idx):
        xs, ys = [], []
        for i in range(len(data) - window_size):
            x = data[i:i+window_size]
            y = data[i+window_size, target_col_idx]
            xs.append(x)
            ys.append(y)
        return np.array(xs), np.array(ys)

    train_data = scaled[train_idx.to_numpy()]
    test_data = scaled[test_idx.to_numpy()]
    X_train, y_train = create_sequences(train_data, window_size, target_col_idx)
    X_test, y_test = create_sequences(test_data, window_size, target_col_idx)

    X_train = torch.tensor(X_train, dtype=torch.float32).to(device)
    y_train = torch.tensor(y_train, dtype=torch.float32).unsqueeze(1).to(device)
    X_test = torch.tensor(X_test, dtype=torch.float32).to(device)
    y_test = torch.tensor(y_test, dtype=torch.float32).unsqueeze(1).to(device)

    class TransformerModel(nn.Module):
        def __init__(self, input_size, hidden_size, num_layers, nhead):
            super().__init__()
            self.input_proj = nn.Linear(input_size, hidden_size)
            encoder_layer = nn.TransformerEncoderLayer(d_model=hidden_size, nhead=nhead, batch_first=True)
            self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)
            self.decoder = nn.Linear(hidden_size, 1)

        def forward(self, x):
            x = self.input_proj(x)
            x = self.transformer(x)
            return self.decoder(x[:, -1, :])

    model = TransformerModel(input_size=X_train.shape[2], hidden_size=hidden_size,
                             num_layers=num_layers, nhead=nhead).to(device)

    criterion = nn.MSELoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)

    for epoch in range(num_epochs):
        model.train()
        permutation = torch.randperm(X_train.size(0))
        for i in range(0, X_train.size(0), batch_size):
            indices = permutation[i:i + batch_size]
            batch_x, batch_y = X_train[indices], y_train[indices]

            optimizer.zero_grad()
            output = model(batch_x)
            loss = criterion(output, batch_y)
            loss.backward()
            optimizer.step()

    model.eval()
    with torch.no_grad():
        pred_scaled = model(X_test).cpu().numpy()
        actual_scaled = y_test.cpu().numpy()

    dummy = np.zeros((len(pred_scaled), len(features)))
    dummy[:, target_col_idx] = pred_scaled[:, 0]
    pred_actual = scaler.inverse_transform(dummy)[:, target_col_idx]

    dummy[:, target_col_idx] = actual_scaled[:, 0]
    true_actual = scaler.inverse_transform(dummy)[:, target_col_idx]

    plot_dates = df[test_idx].iloc[window_size:]['Date'].reset_index(drop=True)

    fig, ax = plt.subplots(figsize=(12, 5))
    ax.plot(plot_dates, true_actual, label="Actual 2024 Sales")
    ax.plot(plot_dates, pred_actual, label="Predicted 2024 Sales")
    ax.set_title(f"Sales Prediction (2024) - {district_selected}, MRP Rs.{mrp_selected}")
    ax.set_xlabel("Date")
    ax.set_ylabel("Billed Quantity")
    ax.grid(True)
    ax.legend()
    plt.tight_layout()

    return fig
