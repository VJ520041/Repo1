import streamlit as st
from trans import run_lstm_forecast  # <- this is your function

# UI layout
st.title("Sales Forecasting App - Dreamlite")

file_path = 'Sales_CG_DL_17_25.xlsx'
district = st.text_input("Enter District", value="BILASPUR")
mrp = st.number_input("Enter MRP", min_value=1, max_value=50, value=5)
target_month = st.text_input("Enter Target Month (YYYY-MM)", value="2024-03")

if st.button("Predict Sales"):
    try:
        y_actual, y_pred, fig = run_lstm_forecast(file_path, district, mrp, target_month)
        st.write(f"**Predicted sales for {target_month}**: {y_pred:.2f}")
        st.write(f"**Actual sales for {target_month}**: {y_actual:.2f}")
        st.pyplot(fig)
    except Exception as e:
        st.error(f"Error: {e}")


# streamlit run app.py