import streamlit as st
from new_tran import run_transformer_forecast

st.title("Transformer-Based Sales Forecasting (Dreamlite)")

file_path = 'Sales_CG_DL_17_25.xlsx'

district = st.text_input("Enter District", value="Raipur")
mrp = st.number_input("Enter MRP", min_value=1, max_value=50, value=10)

if st.button("Run Forecast"):
    with st.spinner("Running Transformer Model..."):
        try:
            fig = run_transformer_forecast(file_path, district, mrp)
            st.pyplot(fig)
        except Exception as e:
            st.error(f"Error: {e}")
